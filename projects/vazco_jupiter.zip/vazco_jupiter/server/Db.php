﻿<?php

	class Db
	{
		public function Save($table, $items)
		{
			//generate insert
			//DbHandle Query
		}
	}