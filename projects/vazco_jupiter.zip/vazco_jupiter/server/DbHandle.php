﻿<?php

	class DbHandle 
	{
	//postgres lub nie
		public function Query($query)
		{
			
		}
	}