﻿function RegisterAll() {
    // on ready
  
    RegisterClick('aboutClick', AboutLinkClick);
    RegisterClick('howItWorksClick', HowItWorksLinkClick);
    RegisterClick('organisersClick', OrganisersLinkClick);
    RegisterClick('faqClick', FAQLinkClick);
    RegisterClick('applyClick', ApplyLinkClick);
    RegisterClick('contactClick', ContactLinkClick);
    RegisterClick('about2Click', About2Click);
    RegisterClick('moreButtonClick', MoreButtonClick);


}