

function AboutLinkClick() {
    GetHtmlByAjax("dane/aboutCourse.html", insertHTML, "centralContent");
}

function HowItWorksLinkClick() {

    GetHtmlByAjax("dane/howItWorks.html", insertHTML,"centralContent");
}

function OrganisersLinkClick() {

    GetHtmlByAjax("dane/organisers.html", insertHTML,"centralContent");
}

function FAQLinkClick() {

    GetHtmlByAjax("dane/faq.html", insertHTML,"centralContent");
}

function ApplyLinkClick() {

    GetHtmlByAjax("dane/apply.html", insertHTML,"centralContent");
}

function ContactLinkClick() {

    GetHtmlByAjax("dane/contact.html", insertHTML,"centralContent");
}

function About2Click() {

    GetHtmlByAjax("dane/about2.html", insertHTML,"centralContent");
}

function MoreButtonClick() {

    GetHtmlByAjax("dane/aboutCourse.html", insertHTML,"centralContent");
}