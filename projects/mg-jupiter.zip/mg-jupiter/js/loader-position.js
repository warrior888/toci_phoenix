/**
 * Created by Mg on 2015-07-31.
 */

var height = window.innerHeight/3;
height = height+"px auto";
document.getElementById("loader").style.margin = height;
